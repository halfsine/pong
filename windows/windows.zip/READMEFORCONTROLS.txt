W: Move paddle up
S: Move paddle down
ESCAPE: Pause menu